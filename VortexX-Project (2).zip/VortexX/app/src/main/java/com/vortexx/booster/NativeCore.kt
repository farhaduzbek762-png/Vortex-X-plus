package com.vortexx.booster

import android.system.Os
import java.io.FileDescriptor
import java.nio.ByteBuffer

/**
 * هسته VORTEX-X — لایه تدافعی (🛡️ اسکنر):
 * اگر کتابخانه نیتیو در APK باشد مسیر Rust/C++ فرمانده اجرا می‌شود،
 * وگرنه فالبک خالص Kotlin فعال می‌شود — هیچ‌وقت کرش ندارد.
 */
object NativeCore {

    // بارگذاری تدافعی: نبود .so = کرش نیست
    val nativeReady: Boolean = try {
        System.loadLibrary("vortex_engine") // هسته Rust + پل C++ (کد فرمانده)
        true
    } catch (_: Throwable) {
        false
    }

    // اعلان‌های نیتیو (پل C++ — نام‌ها با JNIEXPORTهای پل هم‌خوان است)
    private external fun nLockKernelSocketPriority(fd: Int): Boolean
    private external fun nInjectVipHeaderNative(buffer: ByteBuffer, length: Int): Boolean
    private external fun nTrigger5GKeepAlive()
    private external fun nStartSocksTunnel(configPath: String): Int
    private external fun nStopSocksTunnel()

    fun lockKernelSocketPriority(fd: Int): Boolean = when {
        nativeReady -> try { nLockKernelSocketPriority(fd) } catch (_: Throwable) { kotlinLockPriority(fd) }
        else -> kotlinLockPriority(fd)
    }

    fun injectVipHeaderNative(buffer: ByteBuffer, length: Int): Boolean = when {
        nativeReady -> try { nInjectVipHeaderNative(buffer, length) } catch (_: Throwable) { kotlinInjectVipHeader(buffer, length) }
        else -> kotlinInjectVipHeader(buffer, length)
    }

    fun trigger5GKeepAlive() {
        if (nativeReady) try { nTrigger5GKeepAlive() } catch (_: Throwable) {}
    }

    /** خروجی: 0=شروع شد، -1=در حال اجرا، -2=موتور تونل در APK نیست */
    fun startSocksTunnel(configPath: String): Int {
        if (!nativeReady) return -2
        return try { nStartSocksTunnel(configPath) } catch (_: Throwable) { -2 }
    }

    fun stopSocksTunnel() {
        if (nativeReady) try { nStopSocksTunnel() } catch (_: Throwable) {}
    }

    // ── فالبک خالص Kotlin (بدون نیتیو) ──

    private fun kotlinLockPriority(fd: Int): Boolean = try {
        val f = fileDescriptorFromInt(fd)
        Os.setsockoptInt(f, 1 /* SOL_SOCKET */, 12 /* SO_PRIORITY */, 6)
        Os.setsockoptInt(f, 0 /* IPPROTO_IP */, 1 /* IP_TOS */, 0xB8)
        true
    } catch (_: Throwable) {
        false
    }

    private fun fileDescriptorFromInt(fd: Int): FileDescriptor {
        val fdObj = FileDescriptor()
        FileDescriptor::class.java.getDeclaredField("descriptor").apply {
            isAccessible = true
        }.setInt(fdObj, fd)
        return fdObj
    }

    private fun kotlinInjectVipHeader(buffer: ByteBuffer, length: Int): Boolean = try {
        val pos = buffer.position()
        val b0 = buffer.get(pos).toInt() and 0xFF
        if (length < 20 || (b0 shr 4) != 4) false
        else {
            buffer.put(pos + 1, ((buffer.get(pos + 1).toInt() and 0x03) or 0xB8).toByte()) // DSCP EF
            buffer.put(pos + 10, 0.toByte())
            buffer.put(pos + 11, 0.toByte())
            var sum = 0
            var i = 0
            while (i < 20) {
                sum += ((buffer.get(pos + i).toInt() and 0xFF) shl 8) or
                        (buffer.get(pos + i + 1).toInt() and 0xFF)
                i += 2
            }
            while (sum shr 16 != 0) sum = (sum and 0xFFFF) + (sum shr 16)
            val ck = sum.inv() and 0xFFFF
            buffer.put(pos + 10, ((ck shr 8) and 0xFF).toByte())
            buffer.put(pos + 11, (ck and 0xFF).toByte())
            true
        }
    } catch (_: Throwable) {
        false
    }
}
