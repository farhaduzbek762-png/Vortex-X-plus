#include <jni.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <dlfcn.h>
#include <android/log.h>
#include <string>
#include <thread>

#ifdef VORTEX_WITH_RUST
// هسته Rust فرمانده — فقط وقتی cargo-ndk اجرا شده باشد لینک می‌شود
extern "C" {
extern bool vortex_process_packet_nanosecond(unsigned char* packet, size_t len);
extern void vortex_fire_5g_keepalive_pulse(const unsigned char* ip, size_t len);
}
#endif

// [تایتان/ترمیم آلفا] موتور hev در زمان اجرا با dlopen بارگذاری می‌شود —
// وابستگی لینک‌زمانی حذف شد تا بیلد بدون hev هم سبز شود؛ اگر .so در APK
// نباشد، startSocksTunnel کد -2 برمی‌گرداند (نه کرش، نه خطای لینکر)
typedef int  (*hev_main_fn)(const char *config_path);
typedef void (*hev_term_fn)(void);

static void*        g_hev_lib    = nullptr;
static hev_main_fn  g_hev_main   = nullptr;
static hev_term_fn  g_hev_term   = nullptr;
static std::thread* g_hev_thread = nullptr;

#define VLOG(...) __android_log_print(ANDROID_LOG_WARN, "VORTEX", __VA_ARGS__)

// [فالبک C++] تزریق DSCP EF (0xB8) + بازمحاسبه چک‌سام RFC 1071 — وقتی Rust نیست
static bool inject_dscp_ef_fallback(unsigned char* p, size_t len) {
    if (len < 20 || (p[0] >> 4) != 4) return false;
    p[1] = (unsigned char)((p[1] & 0x03) | 0xB8); // DSCP EF (46) << 2 | ECN
    p[10] = 0; p[11] = 0;                          // پاک کردن چک‌سام قبلی
    unsigned sum = 0;
    for (int i = 0; i < 20; i += 2) sum += ((unsigned)p[i] << 8) | p[i + 1];
    while (sum >> 16) sum = (sum & 0xFFFF) + (sum >> 16);
    unsigned short ck = (unsigned short)(~sum);
    p[10] = (unsigned char)(ck >> 8);
    p[11] = (unsigned char)(ck & 0xFF);
    return true;
}

extern "C" {

// ۱. قفل سخت‌افزاری سوکت شبکه روی اولویت ۶ کرنل (خالص C++ — همیشه فعال)
JNIEXPORT jboolean JNICALL
Java_com_vortexx_booster_NativeCore_nLockKernelSocketPriority(JNIEnv* env, jobject thiz, jint fd) {
    (void)env; (void)thiz;
    if (fd < 0) return JNI_FALSE;
    int priority = 6; // بالاترین اولویت صف مخابراتی لینوکس
    setsockopt(fd, SOL_SOCKET, SO_PRIORITY, &priority, sizeof(priority));

    int tos = IPTOS_LOWDELAY | 0xB8; // [اصلاح آلفا] IPPROTO_IP استاندارد Bionic/NDK
    setsockopt(fd, IPPROTO_IP, IP_TOS, &tos, sizeof(tos));

    int buf = 524288; // بافر ۵۱۲ کیلوبایت برای جلوگیری از صف کشیدن گلوله‌ها
    setsockopt(fd, SOL_SOCKET, SO_SNDBUF, &buf, sizeof(buf));
    setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &buf, sizeof(buf));
    return JNI_TRUE;
}

// ۲. ارسال بسته به موتور Rust در کسری از نانوثانیه — وگرنه فالبک C++
JNIEXPORT jboolean JNICALL
Java_com_vortexx_booster_NativeCore_nInjectVipHeaderNative(JNIEnv* env, jobject thiz, jobject direct_buffer, jint length) {
    (void)thiz;
    auto* raw_pkt = static_cast<unsigned char*>(env->GetDirectBufferAddress(direct_buffer));
    if (!raw_pkt) return JNI_FALSE;
#ifdef VORTEX_WITH_RUST
    return vortex_process_packet_nanosecond(raw_pkt, static_cast<size_t>(length)) ? JNI_TRUE : JNI_FALSE;
#else
    return inject_dscp_ef_fallback(raw_pkt, static_cast<size_t>(length)) ? JNI_TRUE : JNI_FALSE;
#endif
}

// ۳. شلیک پالس ضد خواب آنتن 5G — مسیر Rust؛ بدون Rust پالس Kotlin فعال است
JNIEXPORT void JNICALL
Java_com_vortexx_booster_NativeCore_nTrigger5GKeepAlive(JNIEnv* env, jobject thiz) {
    (void)env; (void)thiz;
#ifdef VORTEX_WITH_RUST
    vortex_fire_5g_keepalive_pulse(nullptr, 0);
#endif
}

// ۴. [تایتان] راه‌اندازی موتور تونل (TCP+UDP) — dlopen در زمان اجرا
//    خروجی: 0=شروع شد، -1=در حال اجرا، -2=موتور hev در APK نیست
JNIEXPORT jint JNICALL
Java_com_vortexx_booster_NativeCore_nStartSocksTunnel(JNIEnv* env, jobject thiz, jstring config_path) {
    (void)thiz;
    if (g_hev_thread != nullptr) return -1; // در حال اجراست

    if (g_hev_lib == nullptr) {
        g_hev_lib = dlopen("libhev-socks5-tunnel.so", RTLD_NOW | RTLD_LOCAL);
        if (g_hev_lib == nullptr) {
            VLOG("hev tunnel .so not found: %s", dlerror());
            return -2;
        }
        g_hev_main = reinterpret_cast<hev_main_fn>(dlsym(g_hev_lib, "hev_socks5_tunnel_main"));
        g_hev_term = reinterpret_cast<hev_term_fn>(dlsym(g_hev_lib, "hev_socks5_tunnel_terminate"));
        if (g_hev_main == nullptr || g_hev_term == nullptr) {
            VLOG("hev symbols missing");
            dlclose(g_hev_lib);
            g_hev_lib = nullptr;
            return -2;
        }
    }

    const char* p = env->GetStringUTFChars(config_path, nullptr);
    std::string cfg(p);
    env->ReleaseStringUTFChars(config_path, p);

    hev_main_fn fn = g_hev_main;
    g_hev_thread = new std::thread([cfg, fn]() {
        fn(cfg.c_str()); // بلوک می‌شود تا terminate
    });
    return 0;
}

// ۵. [تایتان] توقف ایمن موتور تونل
JNIEXPORT void JNICALL
Java_com_vortexx_booster_NativeCore_nStopSocksTunnel(JNIEnv* env, jobject thiz) {
    (void)env; (void)thiz;
    if (g_hev_term != nullptr) g_hev_term();
    if (g_hev_thread != nullptr) {
        if (g_hev_thread->joinable()) g_hev_thread->join();
        delete g_hev_thread;
        g_hev_thread = nullptr;
    }
}

} // extern "C"
